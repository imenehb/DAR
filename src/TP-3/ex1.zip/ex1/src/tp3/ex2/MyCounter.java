package tp3.ex2;

public class MyCounter {

    //todo : implement me
    public void count(){
        for(int i=0;i<=500;i++){
            System.out.println(i);
        }
        System.out.println("Finish !");
        //print the first 500 numbers and then print 'finish !!'
    }
}
